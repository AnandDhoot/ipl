void foo ( ) 
{	int s,a,a2;
	a = s->b ;
	a=3.23;
	y= x(y(i,j),l);
	for (x=0; x <y; x++){

			for (x=0; x <10; x++){
				if (y >1) {x=x-1; y=y+1;} else ;
			}
	}
if (y >1) {x=x-1; y=y+1;} else ;
}

