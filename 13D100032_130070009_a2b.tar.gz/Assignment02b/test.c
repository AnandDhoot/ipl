int returnInt () {
    return 1;
}

int main() {
    int a;
    int b;
    int c[3];
}