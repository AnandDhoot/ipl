
void main()
{
  float y0,x0;
  y0=x0=3;
  printf(y0,x0);
}
