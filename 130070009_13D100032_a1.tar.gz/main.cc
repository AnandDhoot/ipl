#include <iostream>
#include <iomanip>
#include "Parser.h"
using namespace std;
int main (int argc, char** arg)
{
	Parser parser;
	parser.parse();
}
